public class IVA {

  private String descripcion;

  public IVA(String descripcion) {
    this.descripcion = descripcion;
  }

  public String obtenerDescripcion() {
    return this.descripcion;
  }
}
