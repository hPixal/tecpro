public class Pais {

  private String name;
  private Integer arancel;

  public Pais(String name, Integer arancel) {
    this.name = name;
    this.arancel = arancel;
  }

  public String getName() {
    return name;
  }

  public Integer getArancel() {
    return arancel;
  }
}
