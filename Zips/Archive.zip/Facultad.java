import java.util.Calendar;

public class Facultad {

  private String sigla;

  public Facultad(String sigla) {
    this.sigla = sigla;
  }

  public String getSigla() {
    return sigla;
  }

}
