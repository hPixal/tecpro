package ejercicio;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
