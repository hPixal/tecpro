package ejercicio;

public class Comentario {
	//Atributos
	private String comentario;
	private Short estrellas;
		//DE LAS RELACIONES
	private PersonaRol aPersonaRol;
	
	//Constructor
		public Comentario(String comentario, Short estrellas, PersonaRol aPersonaRol) {
			super();
			this.comentario = comentario;
			this.estrellas = estrellas;
			this.aPersonaRol = aPersonaRol;
		}
		
	//Comportamiento
	
	public void mostrar() {
		System.out.print(comentario + " - " + estrellas + " estrellas");
		aPersonaRol.mostrarHospedaje();
	}
	public Boolean esNestrellas(Short N) {
		return estrellas.equals(N);
	}
	public Boolean esDehuesped() {
		return aPersonaRol.esHuesped();
	}
	
	public Boolean perteneceAnio(Short anio) {
		return aPersonaRol.esdeAnio(anio);
	}
	/*
	public void mostrar5estrellaAnio(Short anio) {
		if(estrellas.equals((short) 5) && aPersonaRol.esHuesped() && aPersonaRol.esdeAnio(anio)) {
			this.mostrar();
		}
	}*/
	
}
