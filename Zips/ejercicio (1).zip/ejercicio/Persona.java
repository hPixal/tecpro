package ejercicio;

import java.util.Vector;

public class Persona {
	//Atributos
	private String nombre;
	private String email;
		//de las relaciones
	private Vector<Comentario> cComentario;
	private AirBnB aAirBnB;
	private Vector<PersonaRol> cPersonaRol;
	//Constructor
	public Persona(String nombre, String email, AirBnB aAirBnB) {
		super();
		this.nombre = nombre;
		this.email = email;
		this.cComentario = new Vector<Comentario>();
		this.aAirBnB = aAirBnB;
		this.cPersonaRol = new Vector<PersonaRol>();
	}
	//Comportamiento
	public void mostrarComen5Estrellasanio(Short anio) {
		for(Comentario oComen : cComentario) {
			//oComen.mostrar5estrellaAnio(anio);
			if(oComen.esDehuesped() && oComen.esNestrellas((short)5) && oComen.perteneceAnio(anio)) {
				oComen.mostrar();
			}
		}
	}
	
}
