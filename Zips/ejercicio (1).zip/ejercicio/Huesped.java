package ejercicio;

import java.util.Calendar;

public class Huesped extends PersonaRol {
	//Atributos
	private Calendar nacimiento;
		//de las relaciones
	private Alquiler aAlquiler;
	
	//Constructor
	public Huesped(Persona aPersona,Calendar nacimiento, Alquiler aAlquiler) {
		super(aPersona);
		this.nacimiento = nacimiento;
		this.aAlquiler = aAlquiler;
	}
	
	//Comportamiento
	
	@Override
	public Boolean esHuesped() {
		return true;
	}
	@Override
	public void mostrarHospedaje() {
		this.aAlquiler.mostrarDirecHospedaje();
	}
	@Override
	public Boolean esdeAnio(Short anio) {
		return aAlquiler.esAnio(anio);
	}
}
