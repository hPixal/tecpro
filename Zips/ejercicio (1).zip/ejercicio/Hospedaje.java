package ejercicio;

import java.util.Vector;

public class Hospedaje {
	//Atributos
	
	private Integer capacidad;
	private String direccion;
		//de las relaciones:
	private Vector<Alquiler> cAlquiler;
	private Anfitrion aAnfitrion; // en el uml no lo dice, pero lo tome como un relacion de 1
	
	//Constructor
	public Hospedaje(Integer capacidad, String direccion, Anfitrion aAnfitrion) {
		super();
		this.capacidad = capacidad;
		this.direccion = direccion;
		this.cAlquiler = new Vector<Alquiler>();
		this.aAnfitrion = aAnfitrion;
	}
	
	//Comportamiento
	
	public void mostrarDireccion() {
		System.out.print("- " + direccion);
	}
	
}
