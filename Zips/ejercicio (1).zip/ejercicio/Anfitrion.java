package ejercicio;

public class Anfitrion extends PersonaRol{
	//Atributo
	String usuario;
	//Constructor
	public Anfitrion(Persona aPersona, String usuario) {
		super(aPersona);
		this.usuario = usuario;
	}
	
	
}
