package ejercicio;

import java.util.Calendar;

public class Alquiler {
	//Atributos
	private Float precio;
	private Calendar desde;
	private Calendar hasta;
	  //de la relacion
	private AirBnB aAirBnb;
	private Hospedaje aHospedaje;
	
	//Constructor
	public Alquiler(Float precio, Calendar desde, Calendar hasta, AirBnB aAirBnb, Hospedaje aHospedaje) {
		super();
		this.precio = precio;
		this.desde = desde;
		this.hasta = hasta;
		this.aAirBnb = aAirBnb;
		this.aHospedaje = aHospedaje;
	}
	//Comportamiento
	public void mostrarDirecHospedaje() {
		aHospedaje.mostrarDireccion();
	}
	
	public Boolean esAnio(Short anio) {
		return (desde.equals(anio) || hasta.equals(anio));
	}

	
}
