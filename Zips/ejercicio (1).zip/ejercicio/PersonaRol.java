package ejercicio;

public class PersonaRol {
	//Atributo
	private Persona aPersona;

	//Constructor
	public PersonaRol(Persona aPersona) {
		super();
		this.aPersona = aPersona;
	}
	
	//Comportamiento
	public Boolean esHuesped() {
		return false;
	}
	public void mostrarHospedaje() {
		System.out.print(".");
	}
	
	public Boolean esdeAnio(Short anio) {
		return false;
	}
}
