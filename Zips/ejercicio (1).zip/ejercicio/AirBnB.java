package ejercicio;

import java.util.Vector;

public class AirBnB {
	//Atributos
	private Vector<Hospedaje> cHospedaje;
	private Vector<Persona> cClientes;
	private Vector<Alquiler> cAlquiler;
	//Constructor
	public AirBnB() {
		super();
		this.cHospedaje = new Vector<Hospedaje>();
		this.cClientes = new Vector<Persona>();
		this.cAlquiler = new Vector<Alquiler>();
	}
	
	//Comportamiento
	public void mostrar5EstrellasxAnio(Short anio) {
		for(Persona oPersona : cClientes) {
			oPersona.mostrarComen5Estrellasanio(anio);
		}
	}
}
