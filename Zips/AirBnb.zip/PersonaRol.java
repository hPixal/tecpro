
public abstract class PersonaRol {
	private Persona persona;

	public PersonaRol(Persona persona) {
		this.persona = persona;
	}
	
	public abstract Boolean EsHuesped();

	public abstract boolean hospedadoElA�o(Short a�o);

	public abstract void mostrarDireccion();

	public void addComentario(Comentario comentario) {
		persona.addComentario(comentario);
	}
}
