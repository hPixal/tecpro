import java.util.Calendar;

public class Principal {
	
	
	public static void main(String[] args) {
		AirBnb airbnb = new AirBnb();
		Persona per = new Persona("Alejandro Escudero", "alej@gmail.com", airbnb);
		Anfitrion anf = new Anfitrion(per, "10002");
		Hospedaje hosp = new Hospedaje(4,"bv galvez 1345",anf);
		Alquiler alq = new Alquiler(300f,airbnb,hosp);
		Huesped hue = new Huesped(per,Calendar.getInstance(),alq);
		Comentario com = new Comentario("goooood",(short) 5,hue);
		Comentario com2 = new Comentario("ta bueno",(short) 5,hue);
		
		airbnb.mostrar5EstrellasxA�o((short) 2022);
		
	}
}
