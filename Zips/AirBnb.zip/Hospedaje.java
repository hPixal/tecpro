import java.util.Vector;

public class Hospedaje {
	private Integer capacidad;
	private String direccion;
	private Anfitrion anfitrion;
	private Vector<Alquiler> alquileres;
	
	public Hospedaje(Integer capacidad, String direccion, Anfitrion anfitrion) {
		this.capacidad = capacidad;
		this.direccion = direccion;
		this.anfitrion = anfitrion;
		this.alquileres = new Vector<Alquiler>();
	}
	
	public void addAlquiler(Alquiler a) {
		alquileres.add(a);
	}
	
	public void mostrarDireccion() {
		System.out.println(" - "+direccion);
	}
}
