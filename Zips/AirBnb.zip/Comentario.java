
public class Comentario {
	private String comentario;
	private Short estrellas;
	private PersonaRol rol;
	
	public Comentario(String comentario, Short estrellas,PersonaRol rol) {
		this.comentario = comentario;
		this.estrellas = estrellas;
		this.rol = rol;
		rol.addComentario(this);
	}
	
	public Boolean tiene5Estrellas() {
		return estrellas == 5;
	}
	
	public void mostrar() {
		System.out.print(comentario + " - " + estrellas);
	}
	public void mostrar5EstrellasxA�o(Short a�o) {
		if(this.tiene5Estrellas() && rol.EsHuesped() && rol.hospedadoElA�o(a�o)) {
			this.mostrar();
			rol.mostrarDireccion();
		}
	}
	
	
}
