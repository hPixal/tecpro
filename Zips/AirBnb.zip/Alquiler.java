import java.util.Calendar;
import java.util.Vector;

public class Alquiler {

	private Float precio;
	private Calendar desde;
	private Calendar hasta;
	private Huesped responsable;
	private Vector<Huesped> grupo;
	private AirBnb airbnb;
	private Hospedaje hospedaje;
	
	public Alquiler(Float precio, Calendar desde, Calendar hasta,
			AirBnb airbnb, Hospedaje hospedaje) {
		this.precio = precio;
		this.desde = desde;
		this.hasta = hasta;
		this.grupo = new Vector<Huesped>();
		this.airbnb = airbnb;
		this.hospedaje = hospedaje;
		
		airbnb.addAlquiler(this);
		hospedaje.addAlquiler(this);
	}
	
	// constructor por si el cliente no especifica una fecha.
	public Alquiler(Float precio, AirBnb airbnb, Hospedaje hospedaje) {
		this.precio = precio;
		// fecha desde es el d�a actual, fecha hasta es el d�a actual + 1.
		this.desde = Calendar.getInstance();
		this.hasta = Calendar.getInstance();
		this.hasta.add(Calendar.DAY_OF_MONTH, 1);
		this.grupo = new Vector<Huesped>();
		this.airbnb = airbnb;
		this.hospedaje = hospedaje;
		
		airbnb.addAlquiler(this);
		hospedaje.addAlquiler(this);
	}

	public void addResponsable(Huesped huesped) {
		responsable = huesped;
	}
	public void addHuesped(Huesped huesped) {
		grupo.add(huesped);
	}

	public boolean esDelA�o(Short a�o) {
		return (desde.get(Calendar.YEAR) == a�o || hasta.get(Calendar.YEAR) == a�o);
	}

	public void mostrar() {
		hospedaje.mostrarDireccion();
	}
	
	
}
