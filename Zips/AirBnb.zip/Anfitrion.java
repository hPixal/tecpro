
public class Anfitrion extends PersonaRol {
	private String usuario;
	
	public Anfitrion(Persona persona, String usuario) {
		super(persona);
		this.usuario = usuario;
		persona.addRol(this);
	}

	public Boolean EsHuesped() {
		return false;
	}

	public boolean hospedadoElA�o(Short a�o) {
		return false;
	}

	public void mostrarDireccion() {
	}
}
