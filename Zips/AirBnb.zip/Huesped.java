import java.util.Calendar;

public class Huesped extends PersonaRol {
	private Calendar nacimiento;
	private Alquiler alquiler;
	
	public Huesped(Persona persona, Calendar nacimiento, Alquiler alquiler) {
		super(persona);
		this.nacimiento = nacimiento;
		this.alquiler = alquiler;
		alquiler.addHuesped(this);
		persona.addRol(this);
	}

	public Boolean EsHuesped() {
		return true;
	}

	@Override
	public boolean hospedadoElA�o(Short a�o) {
		return alquiler.esDelA�o(a�o);
	}

	@Override
	public void mostrarDireccion() {
		alquiler.mostrar();
	}
	
}
