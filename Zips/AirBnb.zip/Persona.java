import java.util.Vector;

public class Persona {
	private String nombre;
	private String email;
	private AirBnb airbnb;
	private Vector<Comentario> comentarios;
	private Vector<PersonaRol> roles;
	
	public Persona(String nombre, String email, AirBnb airbnb) {
		this.nombre = nombre;
		this.email = email;
		this.airbnb = airbnb;
		this.comentarios = new Vector<Comentario>();
		this.roles = new Vector<PersonaRol>();
		
		airbnb.addPersona(this);
	}

	public void addComentario(Comentario c) {
		comentarios.add(c);
	}
	public void addRol(PersonaRol pr) {
		roles.add(pr);
	}
	public void mostrar5EstrellasxA�o(Short a�o) {
		for(Comentario oComentario : comentarios) {
			oComentario.mostrar5EstrellasxA�o(a�o);
		}
	}
	
	
}
