import java.util.Vector;

public class AirBnb {
	private Vector<Persona> cClientes;
	private Vector<Hospedaje> cHospedajes;
	private Vector<Alquiler> cAlquileres;
	public AirBnb() {
		super();
		this.cClientes = new Vector<Persona>();
		this.cHospedajes = new Vector<Hospedaje>();
		this.cAlquileres = new Vector<Alquiler>();
	}
	
	public void addAlquiler(Alquiler a) {
		cAlquileres.add(a);
	}
	
	public void addPersona(Persona p) {
		cClientes.add(p);
	}
	
	public void addHospedaje(Hospedaje h) {
		cHospedajes.add(h);
	}
	
	public void mostrar5EstrellasxA�o(Short a�o) {
		for(Persona oPersona : cClientes) {
			oPersona.mostrar5EstrellasxA�o(a�o);
		}
	}
}
