public class Neurologica extends EnfermedadCongenita {
    public Neurologica(String nombre, Integer newAttr) {
        super(nombre, newAttr);
    }
}
