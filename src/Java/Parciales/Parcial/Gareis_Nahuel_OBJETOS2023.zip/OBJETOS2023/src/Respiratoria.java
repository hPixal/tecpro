public class Respiratoria extends EnfermedadCongenita {
    public Respiratoria(String nombre, Integer newAttr) {
        super(nombre, newAttr);
    }
}
